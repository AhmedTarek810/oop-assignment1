public class Main {
    public static void main(String[] args) {
        Person person = new Person("Ahmed", "Mayami",
                "01145546548", "ahmed@gmail.com");

        Student student = new Student("Mohamed", "Abu qir", "01009546548",
                "mohamed@gmail.com", Student.JUNIOR);

        Employee employee = new Employee("Tarek", "Smouha", "01118545455",
                "tarek@gmail.com", 910, 60000);

        Faculty faculty = new Faculty("Ali", "kafr abdo", "01000656868",
                "ali@gmail.com", 101, 50000, "4pm to 6pm", "Professor");

        Staff staff = new Staff("Marwan", "Cairo", "01552856454",
                "marwan@gmail.com", 12, 65000, "Executive Assistant");


        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
        System.out.println(faculty.toString());
        System.out.println(staff.toString());
    }
}